
import java.util.Random;

public class Main {
    static class No {
        int valor;
        No proximo;

        No(int valor) {
            this.valor = valor;
            this.proximo = null;
        }
    }

    public static void main(String[] args) {
        int[] matriz = new int[100];
        boolean[] ocupado = new boolean[100];
        No[] listas = new No[100];
        Random random = new Random(1090);
        int quantidadeListas = 0;
        int posicaoMaiorLista = -1;
        int tamanhoMaiorLista = 0;
        int posicoesVazias = 0;
        int[] ultimosTres = new int[3];
        int quantidadeUltimos = 0;

        // colocando os 1000 numeros
        for (int i = 0; i < 1000; i++) {
            int numero = random.nextInt(100001);
            int posicao = numero % 100;
            // se a position estiver vazia
            if (ocupado[posicao] == false) {
                matriz[posicao] = numero;
                ocupado[posicao] = true;
            } else {
                // se ñ tiver lista
                if (listas[posicao] == null) {
                    listas[posicao] = new No(matriz[posicao]);
                    quantidadeListas++;
                }
                // novo nó
                No novo = new No(numero);
                // indo até o fim da lista
                No atual = listas[posicao];

                while (atual.proximo != null) {
                    atual = atual.proximo;
                }
                // novo nó final
                atual.proximo = novo;
                // guardar os três ultimos valores
                if (quantidadeUltimos < 3) {
                    ultimosTres[quantidadeUltimos] = numero;
                    quantidadeUltimos++;
                } else {
                    ultimosTres[0] = ultimosTres[1];
                    ultimosTres[1] = ultimosTres[2];
                    ultimosTres[2] = numero;
                }
            }
        }

        // contagem das posições vazias
        for (int i = 0; i < 100; i++) {
            if (ocupado[i] == false) {
                posicoesVazias++;
            }
        }

        // buscando a maior lista
        for (int i = 0; i < 100; i++) {

            if (listas[i] != null) {
                int tamanho = 0;
                No atual = listas[i];

                while (atual != null) {
                    tamanho++;
                    atual = atual.proximo;
                }

                if (tamanho > tamanhoMaiorLista) {
                    tamanhoMaiorLista = tamanho;
                    posicaoMaiorLista = i;
                }
            }
        }

        // maior lista aqui
        System.out.println("MAIOR LISTA ENCADEADA:");

        if (posicaoMaiorLista != -1) {
            No atual = listas[posicaoMaiorLista];
            while (atual != null) {
                System.out.print(atual.valor + " -> ");
                atual = atual.proximo;
            }
            System.out.println("null");
            System.out.println("Tamanho: " + tamanhoMaiorLista);
            System.out.println("Posicao: " + posicaoMaiorLista);
        }
        // resultado
        System.out.println("\nRESULTADOS:");
        System.out.println("Listas encadeadas geradas: " + quantidadeListas);
        System.out.println("Posicoes vazias: " + posicoesVazias);
        System.out.println("\nULTIMOS TRES VALORES INSERIDOS NAS LISTAS:");

        for (int i = 0; i < quantidadeUltimos; i++) {
            System.out.println(ultimosTres[i]);
        }
    }
}
